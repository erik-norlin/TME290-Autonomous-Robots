#ifndef PRIMECHECKER
#define PRIMECHECKER

#include <cstdint>

class PrimeChecker {
  public:
    bool isPrime(uint16_t);
};

#endif
