## OpenDLV microservice to integrate the kinematic state of a body into its global position

This microservice calculates the global position of a body by integrating its
kinematic state over time. The calculation uses simple Euler integration and
should therefore run at relatively high frequency. The microservice handles only
one body, so for a multi-body system several instances of the microservice should
be used. If each simulated body is running in separe CIDs, then each integrator
can output results into a joint other CID by using the 
`--extra-cid-out=cid1:senderstamp,cid2:senderstamp` flag where any number of
other CIDs with corresponding sender stamps (within that CID) can be specified.

On systems where the simulation speed needs to be slowed down or when the
simulation speed can be increased, then the integrator can be run using the
`--timemod=X` option where X is a decimal larger than zero.

The starting position of the body can be given using the `--x`, `--y`, `--z`,
`--roll`, `--pitch`, and `--yaw`. In basic ground-based 2D simulations the X,
Y, and yaw is typically enough.

The integrator will listen to `opendlv::sim::KinematicState` messages with the
frame id specified as argument `--frame-id` and output a `opendlv::sim::Frame`
message with the resulting integrated global position.

[![License: GPLv3](https://img.shields.io/badge/license-GPL--3-blue.svg
)](https://www.gnu.org/licenses/gpl-3.0.txt)


## Table of Contents
* [Dependencies](#dependencies)
* [Usage](#usage)
* [License](#license)


## Dependencies
The following dependencies are needed to compile the microservice:
* [Eigen](https://gitlab.com/libeigen/eigen)

## Usage
This microservice is created automatically on tagged versions of this repository via
our own Docker registry found
[here](https://git.opendlv.org/testing/opendlv-virtual-space/container_registry).

These platforms are automatically supported:
* linux/amd64
* linux/arm64
* linux/arm/v7

The Docker image can simply be started as follows:

```
docker run --rm --net=host git.opendlv.org/testing/opendlv-virtual-space:v0.0.8 opendlv-virtual-space --cid=111 --freq=50 --frame-id=0 --x=0.0 --yaw=0.2 --timemod=1.0
```

## License

* This project is released under the terms of the GNU GPLv3 License
